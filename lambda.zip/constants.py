comp_code_dict= {
    "Premier-League": "9",
    "La-Liga": "12",
    "Ligue-1": "13",
    "Serie-A": "11",
    "Bundesliga": "20", 
}


points_decimal = 0.0001
PGD_decimal = 0.001
NGD_decimal = 0.000001
goal_decimal = 0.0000000001

# Set your S3 bucket and object key
bucket_name = 'api-football-storage'

